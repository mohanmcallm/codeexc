import logo from './logo.svg';
import './App.css';
import BingWebSearch from './BingWebSearch';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <h1>Bing Search App</h1>
        <BingWebSearch />
      </header>
    </div>
  );

}

export default App;
