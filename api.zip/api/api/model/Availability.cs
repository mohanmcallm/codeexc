﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace api.model
{
    public class Availability
    {
        public string Start { get; set; }
        public string End { get; set; }
    }
}
