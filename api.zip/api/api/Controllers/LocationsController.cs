﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using api.model;

namespace api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LocationsController : ControllerBase
    {
        private readonly List<Location> locations = new List<Location>
        {
            new Location { Id = 1, LocationName = "supermarket", Availability = new Availability { Start = "10:00 AM", End = "1:00 PM" } },
            new Location { Id = 2, LocationName = "foodmarket", Availability = new Availability { Start = "9:30 AM", End = "12:30 PM" } },
            // Add more locations as needed
        };

        [HttpGet]
        [Route("GetLocations")]
        public IActionResult GetLocations()
        {
            var availableLocations = new List<Location>();
            foreach (var location in locations)
            {
                if (TimeInRange(location.Availability.Start, "10:00 AM", "1:00 PM") &&
                    TimeInRange(location.Availability.End, "10:00 AM", "1:00 PM"))
                {
                    availableLocations.Add(location);
                }
            }

            return Ok(new { Locations = availableLocations });
        }

        private bool TimeInRange(string time, string startTimes, string endTimes)
        {
           // Start time and end time
            DateTime startTime = ParseTime(startTimes);
            DateTime endTime = ParseTime(endTimes);
            DateTime currentTime = ParseTime(time);



            // Subtract start time from end time to get the duration
            TimeSpan duration = endTime - startTime;

            // Add the duration to the start time to get the end time
            DateTime computedEndTime = startTime.Add(duration);

            // Compare computed end time with end time
            bool isEqual = computedEndTime.CompareTo(endTime) == 0;

            // Compare parameter time with start time
            bool isAfterStartTime = currentTime.CompareTo(startTime) >= 0;

            // Compare parameter time with end time
            bool isBeforeEndTime = currentTime.CompareTo(endTime) <= 0;

            if ((isEqual == true) && (isAfterStartTime == true))
            {
                return true;
            }
            else
            {
                return false;
            }


        }




        static DateTime ParseTime(string timeString)
        {
            // Split time string by space to separate time and AM/PM
            string[] parts = timeString.Split(' ');

            // Split time by colon
            string[] timeParts = parts[0].Split(':');

            // Pad single digit hour with leading zero
            string hour = timeParts[0].Length == 1 ? "0" + timeParts[0] : timeParts[0];

            // Join time parts back
            string formattedTime = hour + ":" + timeParts[1] + " " + parts[1];

            // Parse formatted time
            return DateTime.ParseExact(formattedTime, "hh:mm tt", null);
        }

    }



}
